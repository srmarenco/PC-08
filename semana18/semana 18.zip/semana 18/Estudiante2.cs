public class Estudiantes2{
    public static int PromedioGeneral(int[] notas){
        int cont = 0;
        for (int i = 0; i < 10; i++){
            cont+=notas[i];
        }
        return cont;
    }
}