﻿// Santiago Marenco | 1273525
// Programa: Actividad2
// Descripción: el programa obtiene 8 números del usuario y los agrega a un vector, muestra la suma y el promedio de los números ingresados
// Lenguaje: C#
// fecha: 24/03/2025

using System.Diagnostics.CodeAnalysis;
using System.Globalization;

class semana10{
    static void Main(){
        Console.WriteLine("Porfavor ingrese 8 números");
        double[] numeros = new double[8];
        for (int i=0;i<8;i++){
            double num = double.Parse(Console.ReadLine());
            numeros[i] = num;
        }
        double sum = 0;
        for (int i=0;i<8;i++){
            sum = sum+numeros[i];
        }

        double prom = sum/8;

        Console.Write($"Los números ingresados son: ");

        for (int i=0;i<8;i++){
            Console.Write($"{numeros[i]},");

        }
        Console.WriteLine("");
        Console.WriteLine($"La suma de los números es de {sum}");
        Console.WriteLine($"El promedio de los números es de {prom}");
    }
}
// miku