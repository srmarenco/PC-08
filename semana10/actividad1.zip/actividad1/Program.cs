﻿class clase_semana8
{
    static void Main()
    {
        // 1. Declaración y Asignación Directa
        int[] numeros1 = { 1, 2, 3, 4, 5 };
 
        // 2. Declaración con Espacio Reservado
        int[] numeros2 = new int[5]; // Arreglo de 5 elementos con valores predeterminados (0)
 
        // 3. Declaración y Asignación Separadas
        int[] numeros3;
        numeros3 = new int[] { 10, 20, 30, 40, 50 };
 
        // 4. Arreglo de Strings
        string[] nombres = { "Juan", "Pedro", "María" };
 
        // 5. Arreglo Multidimensional
        int[,] matriz = { { 1, 2 }, { 3, 4 }, { 5, 6 } };
 
        // 6. Arreglo de Objetos
        Persona[] personas = new Persona[]
        {
            new Persona { Nombre = "Mardoqueo" },
            new Persona { Nombre = "Wendy" }
        };
 
        // Mostrar resultados
        Console.WriteLine("Arreglo de números:");
        foreach (var num in numeros1) Console.Write(num + " ");
        Console.WriteLine();
 
        Console.WriteLine("Arreglo de nombres:");
        foreach (var nombre in nombres) Console.Write(nombre + " ");
        Console.WriteLine();
 
        Console.WriteLine("Matriz:");
        for (int i = 0; i < matriz.GetLength(0); i++)
        {
            for (int j = 0; j < matriz.GetLength(1); j++)
            {
                Console.Write(matriz[i, j] + " ");
            }
            Console.WriteLine();
        }
 
        Console.WriteLine("Arreglo de personas:");
        foreach (var persona in personas) Console.WriteLine(persona.Nombre);
 
    }
}